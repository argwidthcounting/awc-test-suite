#!/bin/sh
/usr/bin/gencat --new $1 $2
