extern const char *mandir_of (const char *name);
extern const char *convert_to_cat (const char *name, const char *ext,
				   int standards);
